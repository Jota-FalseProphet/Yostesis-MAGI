package com.magi.api.dto;


public class AusenciaIdDTO {
	private int idAusencia;

	public AusenciaIdDTO(int idAusencia) {
		this.idAusencia = idAusencia;
	}

 	public int getIdAusencia() {
	 	return idAusencia;
 	}
}
