package com.magi.api.controller;

public class AsignacionRequest {
    private String dniAsignat;
    private Long idSessio;
    public String getDniAsignat() { return dniAsignat; }
    public void setDniAsignat(String dniAsignat) { this.dniAsignat = dniAsignat; }
    public Long getIdSessio() { return idSessio; }
    public void setIdSessio(Long idSessio) { this.idSessio = idSessio; }
}
